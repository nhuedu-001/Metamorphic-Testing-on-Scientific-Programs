function [E,U,xx,yy]=Fivepoints(N)%五点差分法
fun=inline('sin(pi*y)');
x0=0;
x1=10;
y0=0;
y1=10;
h=1/N;
x=zeros(1,N);
x(1)=x0+h;
for i=1:(N-1)
    x(i+1)=x(i)+h;
end
y=zeros(1,N);
y(1)=y0+h;
for i=1:(N-1)
    y(i+1)=y(i)+h;
end
A=zeros(N-1,N-1);
A(1,1)=4/(h*h);
A(1,2)=-1/(h*h)+20/h;
A(N-1,N-1)=4/(h*h);
A(N-1,N-2)=-1/(h*h)-20/h;
for i=2:(N-2)
        A(i,i)=4/(h*h);
        A(i,i+1)=-1/(h*h)+20/h;
        A(i,i-1)=-1/(h*h)-20/h;
end
B=zeros(N-1,N-1);
for i=1:(N-1)
    B(i,i)=-1/(h*h);
end
K=kron(diag(ones(1,N-2),1)+diag(ones(1,N-2),-1),B)+kron(diag(ones(1,N-1)),A);
b=zeros(1,(N-1)*(N-1));
for i=1:(N-1)
    b((i-1)*(N-1)+1)=(1/(h*h)+20/h)*feval(fun,y(i));
end
U=K\b';
for i=1:(N-1)
    for j=1:(N-1)
        yy(1,(i-1)*(N-1)+j)=y(i);
    end
end
for i=1:(N-1)
    for j=1:(N-1)
        xx(1,(i-1)*(N-1)+j)=x(j);
    end
end
fun1=inline('sin(pi.*y).*(-exp(20+sqrt(400+pi*pi))/(exp(20-sqrt(400+pi*pi))-exp(20+sqrt(400+pi*pi)))*(exp(20-sqrt(400+pi*pi))).^x+exp(20-sqrt(400+pi*pi))/(exp(20-sqrt(400+pi*pi))-exp(20+sqrt(400+pi)))*(exp(20+sqrt(400+pi))).^x)','x','y');
for i=1:(N-1)*(N-1)
    z(i)=feval(fun1,xx(i),yy(i));
    e(i)=abs(U(i)-z(i));
end
E=max(e);




