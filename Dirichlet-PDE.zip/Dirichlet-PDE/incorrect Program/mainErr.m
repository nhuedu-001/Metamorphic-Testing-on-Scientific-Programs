%Program to solve a  elliptic problem with Dirichlet boundary condition.
%implanting the subtle error.
%调试
clear all; 
clc;
close  all;

%[E,U1,xx1,yy1]=Fivepoints(8);%五点差分法
%[E,U2,xx2,yy2]=V2(8);%有限体积法
%按照二维存U1,U2矩阵为U11,U22，
%n=8;
%U11=zeros(n-1);%U1用于存放向量u中元素二维化后的数据
%U22=zeros(n-1);%U2用于存放真解
%for i=1:n-1%u的一维数据放到二维矩阵U11中
%    for j=1+(i-1)*(n-1):i*(n-1)
%        U11(i,j-(i-1)*(n-1))=U1(j);
%    end
%end
%h=10/128;
%for i=1:n-1%真解产生的节点函数值放到U2中
%    for j=1:n-1
%        U22(i,j)=(((i-1)*h)^2)*(((j-1)*h)^2);
%    end
%end
%输出U11,U22
%U11;
%save u11.txt -ascii U11;
%U22;
%save u22.txt -ascii U22;
% 下面代码是画图
%[X1,Y1,Z1]=griddata(xx1,yy1,U1,linspace(0,1,8)',linspace(0,1,8),'v4');%插值
%[X2,Y2,Z2]=griddata(xx2,yy2,U2,linspace(0,1,8)',linspace(0,1,8),'v4');%插值
%subplot(1,1,1);
%surf(X1,Y1,Z1)%三维曲面
%title('五点差分法');
%hold on;
%subplot(1,2,2);
%surf(X2,Y2,Z2)%三维曲面
%title('有限体积法');
% 以下是画精确解的图
% [x,y]=meshgrid(0:1/20:1);
% z=sin(pi.*y).*(-exp(20+sqrt(400+pi*pi))/(exp(20-sqrt(400+pi*pi))-exp(20+sqrt(400+pi*pi)))*(exp(20-sqrt(400+pi*pi))).^x+exp(20-sqrt(400+pi*pi))/(exp(20-sqrt(400+pi*pi))-exp(20+sqrt(400+pi)))*(exp(20+sqrt(400+pi))).^x);
% subplot(2,2,3);
% mesh(x,y,z);%画出精确解
% title('解析解');
N=[8,16,32,64,128];
nnu=numel(N)
nn=3;%选择观测点x轴坐标点
mm=4;%选择观测点y轴坐标点
ktt=double(zeros(1,nnu));
for i=1:nnu
    t(i,1)=N(i);
    [E,U1,xx1,yy1]=FivepointsErr(N(i));
    e1(i,1)=FivepointsErr(N(i));
   %将每次计算得到的U11,存放到txt文档
     %U111=size(U1);
      for k=1:N(i)-1%u的一维数据放到二维矩阵U111中
          for j=1+(k-1)*(N(i)-1):k*(N(i)-1)
           U111(k,j-(k-1)*(N(i)-1))=U1(j);
          end
      end
      str = ['the',num2str(i),'date.xls'];%数据存放到execl表中
    xlswrite(str,U111);
    kbpsErr(i)=U111(nn*(2^(i-1)),mm*(2^(i-1)));%把指定点的值取出来存放到kbps数组
end
xlswrite('kbpsErr1.xls',kbpsErr);%把指定点的值取出来存放到execl表
%读取某个点的数据（比如某行某列的数据并存起来）
%kbps = double(zeros(1,5));
%for i=1:3
  %  kbps  = xlsread('the1.xls',1,'A1') ;
  %  SS = xlsread('the1date.xls');
  %  nn=3;
  %  mm=4;
  %  kbps(1)=SS(nn,mm);
  %  PP=xlsread('the2date.xls');
  %  kbps(2)=PP(2*nn,2*mm);
  %  RR=xlsread('the3date.xls');
  %  kbps(3)=RR(2*2*nn,2*2*mm);
  %  QQ=xlsread('the4date.xls');
  %  kbps(4)=QQ(2*2*2*nn,2*2*2*mm);
 %    WW=xlsread('the5date.xls');
  %  kbps(5)=WW(2*2*2*2*nn,2*2*2*2*mm);
%    ZZ=xlsread('the6date.xls');
 %    kbps(6)=WW(2*2*2*2*2*nn,2*2*2*2*2*mm);
 %   xlswrite('kbps2.xls',kbps);
    for i=1:nnu-1
        err11(i)=abs(kbpsErr(i)-kbpsErr(i+1));
    end
    %将误差存到execl表中
    xlswrite('err11.xls',err11);
    for i=1:nnu-2
        rotErr12(i)=(err11(i+1))/(err11(i));
        sErr12(i)=log((err11(i+1))/(err11(i)))/log(1/2);
    end
      xlswrite('rotErr12.xls',rotErr12);  
    xlswrite('sErr12.xls',sErr12);
    
   % for i=1:2
    %    s11(1,1)=log((e11(2,1))/(e11(1,1)))/log(1/2);
   %     s11(2,1)=log((e11(3,1))/(e11(2,1)))/log(1/2);
   %     s11(3,1)=log((e11(4,1))/(e11(3,1)))/log(1/2);
       % s11(4,1)=log((e11(5,1))/(e11(4,1)))/log(1/2);
   % end
    %将误差精度阶数存到execl表中
 %   xlswrite('s11.xls',s11);
%for i=1:100
%filename=['d:/test/daxia',第(i)次观测,'.xls']; 
%num=xlsread(filename)
%end

for i=1:2
    s1(i,1)=log2(e1(i,1)/e1(i+1,1));
%    s2(i,1)=log2(e2(i,1)/e2(i+1,1));
end

