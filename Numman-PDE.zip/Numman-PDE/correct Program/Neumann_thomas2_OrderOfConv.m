% Program to solve a Neumann elliptic problem using slow fourier transform
% with order of convergenece 
% and ny solving system of equations using the Thomas alogorithm
%Lab-Sheet Question 3. Change boundary conditions.
% Dr.Yan has added the post deal programm. Then we can check the any point.

clear

a = 0; b = 2;
c = 0; d = 1;

M = 8;
nn=4;%选择观测点x轴坐标点
mm=2;%选择观测点y轴坐标点

tic

for p=1:3
    h(p) = (b-a)/M;
    N = fix((d-c)/h(p));

    x = a+h(p):h(p):b;
    y = c+h(p):h(p):d;

    U = zeros(N,M);
    A = zeros(N);
    g = zeros(M,N);

   
    g(1,1) = f(x(1),y(1)) - 1/h(p)^2 - 1/h(p)^2;
    for j=2:N-1
        g(1,j) = f(x(1),y(j)) - 1/h(p)^2;
    end
    g(1,N) = f(x(1),y(N)) - 1/h(p)^2 - (2*x(1)*exp(x(1)))/h(p);

    g(M,1) = f(x(M),y(1)) - 1/h(p)^2 - (2*y(1)*exp(2*y(1)))/h(p);
    for j=2:N-1
        g(M,j) = f(x(M),y(j)) - (2*y(j)*exp(2*y(j)))/h(p);
    end
    g(M,N) = f(x(M),y(N)) - (2*x(M)*exp(x(M)))/h(p) - (2*y(N)*exp(2*y(N)))/h(p);

    for k=2:M-1
        g(k,1) = f(x(k),y(1)) - (1/h(p)^2);
            for j=2:N-1
            g(k,j) = (f(x(k),y(j)));
            end
        g(k,N) = f(x(k),y(N)) - (2*x(k)*exp(x(k)))/h(p);
    end

    G = h(p)^2*mydst(g);

    % k=1:N-1
    for k=1:M    
        A(1,1) = -(2+4*sin((2*k-1)*pi/(4*M))^2);
        A(1,2) = 1;
        A(N,N-1) = 2;
        A(N,N) = -(2+4*sin((2*k-1)*pi/(4*M))^2);
        for j=2:N-1
            A(j,j) = -(2+4*sin((2*k-1)*pi/(4*M))^2);
            A(j,j-1) = 1;
            A(j,j+1) = 1;
        end
        U(:,k) = thomasSolver(A,G(k,:)');
        %U(:,k) = A\(G(k,:)');
    end

    u = myidst(U');
 %  数据u存放到excel表格中，方便查看
   % str = ['the NeumanP',num2str(p),'date.xls'];%数据存放到execl表中
    %xlswrite(str,u);
    kbps3(p)=u(nn*(2^(p-1)),mm*(2^(p-1)))%把指定点的值取出来存放到kbps3数组
    fprintf('the err of the point (%i %i) in refine mesh is  \n',nn,mm)
 fprintf('the output value of the point in refine mesh is  %0.6f \n',  kbps3)
    
 %%%%%%%%%%%%%%%%%%%
    for i=1:M
        for j=1:N
            usol(i,j)=exp(x(i)*y(j)); %exact solution
        end
    end

    error(p) = max(max(abs(usol-u)));

    M=2*M;

end

for i=1:p-1
        e13(i)=abs(kbps3(i)-kbps3(i+1));
end
 e13
 fprintf('the err of the point (%i %i) in refine mesh is  \n',nn,mm)
 fprintf('the err of the point in refine mesh is  %0.6f \n', e13)
 % xlswrite('e13.xls',e13);
 for i=1:p-2
        rot13(i)=(e13(i+1))/(e13(i));
        s13(i)=log((e13(i+1))/(e13(i)))/log(1/2);
 end
   % xlswrite('rot13.xls',rot13);
  %  xlswrite('s13.xls',s13);
rot13
fprintf('the ration of convergence %0.6f \n' ,rot13)

s13
fprintf('the order of convergence %0.6f \n' ,s13)

error

for j=1:p-1
    order(j)= log(error(j)/error(j+1))/log(2);
end
order

toc

figure(1)
surf(y,x,u);
title('Approximate solution using Fourier Method (Thomas Algorithm)');
xlabel('x');
ylabel('y');


figure(2);
surf(y,x,usol);
title('The exact solution')
