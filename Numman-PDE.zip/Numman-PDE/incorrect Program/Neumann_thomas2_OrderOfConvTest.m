% Program to solve a Neumann elliptic problem 
% with order of convergenece 
% and ny solving system of equations using the Thomas alogorithm
% Dr.Yan has added the post deal programm. Then we can check the any point.

clear

a = 0; b = 2;
c = 0; d = 1;

M = 8;
nn=4;%选择观测点x轴坐标点
mm=2;%选择观测点y轴坐标点

tic

for p=1:5
    h(p) = (b-a)/M;
    N = fix((d-c)/h(p));

    x = a+h(p):h(p):b;
    y = c+h(p):h(p):d;

    U = zeros(N,M);
    A = zeros(N);
    g = zeros(M,N);

   
    g(1,1) = f(x(1),y(1)) - 1/h(p)^2 - 1/h(p)^2;
    for j=2:N-1
         g(1,j) = f(x(1),y(j)) - 1/h(p)^2; % correct code
        %%%implant err "-" changes to "+"
        %g(1,j) = f(x(1),y(j)) + 1/h(p)^2; % the line code includes the buger.
        %%----------------------------------------------------------------------
    end
    g(1,N) = f(x(1),y(N)) - 1/h(p)^2 - (2*x(1)*exp(x(1)))/h(p);

    g(M,1) = f(x(M),y(1)) - 1/h(p)^2 - (2*y(1)*exp(2*y(1)))/h(p);
    for j=2:N-1
        g(M,j) = f(x(M),y(j)) - (2*y(j)*exp(2*y(j)))/h(p);
    end
    %g(M,N) = f(x(M),y(N)) - (2*x(M)*exp(x(M)))/h(p) - (2*y(N)*exp(2*y(N)))/h(p);% correct code
    %%%implant the bugger of  "2" changes to "3", the ecoff changes.
   g(M,N) = f(x(M),y(N)) - (3*x(M)*exp(x(M)))/h(p) - (2*y(N)*exp(2*y(N)))/h(p); % the line code includes the buger.
    %%-----------------------------------------------------------------

    for k=2:M-1
        g(k,1) = f(x(k),y(1)) - (1/h(p)^2);
            for j=2:N-1
            g(k,j) = (f(x(k),y(j)));
            end
        g(k,N) = f(x(k),y(N)) - (2*x(k)*exp(x(k)))/h(p);
    end

    G = h(p)^2*mydst(g);

    % k=1:N-1
    for k=1:M    
        A(1,1) = -(2+4*sin((2*k-1)*pi/(4*M))^2);% correct code
      %%%implant the bugger that the term has been dropped. 
        %A(1,1) = -(4*sin((2*k-1)*pi/(4*M))^2); % the line code includes the buger.
    %%-----------------------------------------------------------------  
        A(1,2) = 1;
        A(N,N-1) = 2;
        A(N,N) = -(2+4*sin((2*k-1)*pi/(4*M))^2);% correct code
         %%%implant the bugger that the term has been dropped. 
        %A(N,N) = -(4*sin((2*k-1)*pi/(4*M))^2); % the line code includes the buger.
    %%-----------------------------------------------------------------
        for j=2:N-1
            A(j,j) = -(2+4*sin((2*k-1)*pi/(4*M))^2);
            A(j,j-1) = 1;
            A(j,j+1) = 1;
        end
        U(:,k) = thomasSolver(A,G(k,:)');
        %U(:,k) = A\(G(k,:)');
    end

    u = myidst(U');
  %  xlswrite('u-err.xls',u);
 %  数据u存放到excel表格中，方便查看
   % str = ['the NeumanP',num2str(p),'date.xls'];%数据存放到execl表中
    %xlswrite(str,u);
    kbps3(p)=u(nn*(2^(p-1)),mm*(2^(p-1)))%把指定点的值取出来存放到kbps3数组
    xlswrite('kbps42-err.xls',kbps3);
    fprintf('the err of the point (%i %i) in refine mesh is  \n',nn,mm)
 fprintf('the output value of the point in refine mesh is  %0.6f \n',  kbps3)
    
 %%%%%%%%%%%%%%%%%%%
    for i=1:M
        for j=1:N
            usol(i,j)=exp(x(i)*y(j)); %exact solution
        end
    end
 
   % xlswrite('usol-err1.xls',usol );
%    kbps4(p)=usol(nn*(2^(p-1)),mm*(2^(p-1))) %把指定点的人工解的值取出来存放到kbps4数组
%    xlswrite('kbps4-71-exact.xls',kbps4);
    error(p) = max(max(abs(usol-u)));
    xlswrite('error-err.xls',error );
    
   % error2(p) = abs(kbps4(p)-kbps3(p));%数值解与人工解在（7，1）点在不同的剖分下比较差值。
   %  xlswrite('error2-42.xls',error2);
     
   % error1(p)= min(min(abs(usol-u)));

    M=2*M;

end
%====================================
for i=1:p-1
        e13(i)=abs(kbps3(i)-kbps3(i+1));
end
 e13
  xlswrite('e42-err.xls',e13);
  fprintf('the err of the point (%i %i) in refine mesh is  \n',nn,mm)
  fprintf('the err of the point in refine mesh is  %0.6f \n', e13)
  %xlswrite('e42.xls',e13);
 %==========================
 for i=1:p-2
       rot13(i)=(e13(i+1))/(e13(i));
        s13(i)=log((e13(i+1))/(e13(i)))/log(1/2);
 end
%    xlswrite('rot42-err.xls',rot13);
%    xlswrite('s42-err.xls',s13);
%rot13
%  fprintf('the ration of convergence %0.6f \n' ,rot13)

%s13
%   fprintf('the order of convergence %0.6f \n' ,s13)
%=================================================
error
%error1

for j=1:p-1
    order(j)= log(error(j)/error(j+1))/log(2);
end
%order

toc

%============drawn single figure=================
  figure(1)
subplot(1,1,1)
surf(y,x,u);
title('Outputs of the incorrect version of P2, mesh N=128');
xlabel('x');
ylabel('y');
hold on

%figure(2)
%subplot(1,2,2)
%surf(y,x,u);
%title('Outputs of the incorrect vesion of P2, mesh N=32');
%xlabel('x');
%ylabel('y');
%hold on


%%=================================

%figure(1)
%subplot(1,2,1)
%surf(y,x,u);
%title('Outputs of the incorrect vesion of P2, mesh N=128');
%xlabel('x');
%ylabel('y');



%subplot(1,2,2)
%surf(y,x,usol);
%title('Outputs of the Manual solution,mesh N=128')
%==========================================================
%figure(3);
%[X1,Y1,Z1]=griddata(x,y,u,linspace(0,2,32)',linspace(0,2,32),'v4');%插值
%subplot(1,1,1);
%surf(X1,Y1,Z1)%三维曲面

%hold on

